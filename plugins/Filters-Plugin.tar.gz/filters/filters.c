/*  Cronos II Message Filters Plugin
 *  Copyright (C) 2001 Bosko Blagojevic
 *
 *  This program is free software; you can redistribute it and/or modify
 *  it under the terms of the GNU General Public License as published by 
 *  the Free Software Foundation; either version 2 of the License, or
 *  (at your option) any later version.
 *  
 *  This program is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *  GNU General Public License for more details.
 *  
 *  You should have received a copy of the GNU General Public License
 *  along with this program; if not, write to the Free Software
 *  Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA 02111-1307, USA.
 **/

/* filters.c 
 * 
 * version 0.3.0
 * 
 * Filters plugin for CronosII
 *
 * By Bosko Blagojevic <falling@users.sourceforge.net>
 * Spring 2001
 * 
 * UNDER CONSTRUCTION!!
 * this is a hard hat area :)
 * 
 * Check README for a TODO list and more info
 **/

#include <cronosII.h>
#include <gnome.h>
#include <stdio.h>
#include <fnmatch.h>

/* Required version */
#define REQUIRE_MAJOR_VERSION 0 /* <0>.2.0 */
#define REQUIRE_MINOR_VERSION 2 /* 0.<2>.0 */
#define REQUIRE_MICRO_VERSION 1 /* 0.2.<0> */
#define FNM_CASEFOLD 1<<4

/* Plug In information */
enum {
  PLUGIN_NAME,
  PLUGIN_VERSION,
  PLUGIN_AUTHOR,
  PLUGIN_URL,
  PLUGIN_DESCRIPTION
};

char *information[] = {
  "CronosII Message Filters",
  "0.3.0",
  "Bosko Blagojevic <falling@users.sourceforge.net>",
  "http://cronosII.sourceforge.net/",
  "A plugin to implement filters support under CronosII."
};

struct Filter {
	gchar *notes;
	gchar *match;
	gchar *action;
};

struct new_filter_fields {
	gint edit;
	GtkWidget *window;
	GtkWidget *NameEntry;
  GtkWidget *DescriptionEntry;
	GtkWidget *MatchTextEntry;
  GtkWidget *MatchWhereCombo;
  GtkWidget *MatchList;
	GtkWidget *CopyButton;
	GtkWidget *CopyMailboxCombo;
	GtkWidget *MoveButton;
	GtkWidget *MoveMailboxCombo;
  GtkWidget *DeleteButton;
	GtkWidget *BeepButton;
};

/* Function definitions */
static void plugin_filters_load_config(const gchar *filename);
static void plugin_filters_save_config(const gchar *filename);
static void plugin_on_download_message(Message *message, gchar **mailbox);
static GtkWidget *plugin_filters_configure(C2DynamicModule *module);
static gboolean match_message(Message *message, gchar *match);
static void act_upon_message(Message *message, gchar **mailbox, gchar *action);
static gchar *filters_get_word(gint num, const gchar *str);
/* GUI Functions */
static gboolean plugin_filters_on_configure_close(GtkWidget *widget, GdkEvent *event, C2DynamicModule *module);
static void plugin_filters_fill_clist(void);
static void plugin_filters_on_configure_exit(GtkButton *widget, C2DynamicModule *module);
static void plugin_filters_on_new_filter(GtkButton *button, GtkWidget *widget);
static void plugin_filters_on_edit_filter(GtkButton *button, GtkWidget *widget);
static void plugin_filters_draw_edit_filter_window(GtkButton *button, GtkWidget *widget, gint edit);
static GtkWidget *plugin_filters_gui_build_mailbox_combo(void);
static void plugin_filters_edit_filter(GtkButton *button, struct new_filter_fields *fields);
static void plugin_filters_new_on_add_match_rule(GtkButton *button, struct new_filter_fields *fields);
static void plugin_filters_new_on_remove_match_rule(GtkButton *button, struct new_filter_fields *fields);
static void plugin_filters_new_on_move_button(GtkButton *button, struct new_filter_fields *fields);
static void plugin_filters_new_on_delete_button(GtkButton *button, struct new_filter_fields *fields);
static void plugin_filters_on_delete_filter(void);

/* Global variables */
static GList *filters = NULL;
static GtkWidget *filters_clist;
static GtkWidget *main_window;

/* Module Initializer */
char *
module_init (int major_version, int minor_version, int patch_version, C2DynamicModule *module) {
  struct Filter *temp;
	
	/* Check if the version is correct */
  if (major_version < REQUIRE_MAJOR_VERSION)
    return g_strdup_printf ("The plugin %s requires at least Cronos II %d.%d.%d.", information[PLUGIN_NAME],
				REQUIRE_MAJOR_VERSION, REQUIRE_MINOR_VERSION, REQUIRE_MICRO_VERSION);
  if (major_version == REQUIRE_MAJOR_VERSION && minor_version < REQUIRE_MINOR_VERSION)
    return g_strdup_printf ("The plugin %s requires at least Cronos II %d.%d.%d.", information[PLUGIN_NAME],
				REQUIRE_MAJOR_VERSION, REQUIRE_MINOR_VERSION, REQUIRE_MICRO_VERSION);
  if (major_version == REQUIRE_MAJOR_VERSION &&
      minor_version == REQUIRE_MINOR_VERSION &&
      patch_version < REQUIRE_MICRO_VERSION)
    return g_strdup_printf ("The plugin %s requires at least Cronos II %d.%d.%d.", information[PLUGIN_NAME],
				REQUIRE_MAJOR_VERSION, REQUIRE_MINOR_VERSION, REQUIRE_MICRO_VERSION);

  /* Check if the module is already loaded */
  if (c2_dynamic_module_find (information[PLUGIN_NAME], config->module_head))
    return g_strdup_printf ("The plugin %s is already loaded.", information[PLUGIN_NAME]);

  /* Set up the module information */
  module->name		= information[PLUGIN_NAME];
  module->version	= information[PLUGIN_VERSION];
  module->author	= information[PLUGIN_AUTHOR];
  module->url		= information[PLUGIN_URL];
  module->description	= information[PLUGIN_DESCRIPTION];
  module->configure	= plugin_filters_configure;
  module->configfile	= c2_dynamic_module_get_config_file (module->name);

  /* Load the configuration */
 	plugin_filters_load_config(module->configfile);
	 
  /* Connect the signals */
  c2_dynamic_module_signal_connect (information[PLUGIN_NAME], C2_DYNAMIC_MODULE_MESSAGE_DOWNLOAD_POP,
  				C2_DYNAMIC_MODULE_SIGNAL_FUNC (plugin_on_download_message));


  /* ~~~~~~~~~~~~ */
	
	return NULL;
}

static void plugin_filters_load_config(const gchar *filename)
{
	FILE *file;
	gchar *temp;
	struct Filter *filter;
	
	if(!(file = fopen(filename, "r"))) 
		return;
	
	for(;;) 
	{
		if(!(temp = fd_get_line(file))) 
			break;
		filter = g_new0(struct Filter, 1);
		filter->notes  = temp;
    filter->match  = fd_get_line(file);
		filter->action = fd_get_line(file);
		filters = g_list_append(filters, filter);
	}
	
	fclose(file);
}

static void plugin_filters_save_config(const gchar *filename)
{
	FILE *file;
	gint i;
	struct Filter *filter;
		
	if(!(file = fopen(filename, "w")))
		return;
	
	for(i=0; i < g_list_length(filters); i++) {
		filter = g_list_nth_data(filters, i);
		fwrite(filter->notes, strlen(filter->notes), 1, file);
		fwrite("\n", 1, 1, file);
		fwrite(filter->match, strlen(filter->match), 1, file);
		fwrite("\n", 1, 1, file);
		fwrite(filter->action, strlen(filter->action), 1, file);
		fwrite("\n", 1, 1, file);
	}
	
	fclose(file);
}

void module_cleanup (C2DynamicModule *module) 
{
  struct Filter *temp;
	gint i;
	g_return_if_fail (module);

	plugin_filters_save_config(module->configfile);
		
	for(i=0; i < g_list_length(filters); i++) {
		temp = g_list_nth_data(filters, i);
		c2_free(temp->notes);
		c2_free(temp->match);
		c2_free(temp->action);
	}

	if(filters != NULL)
		g_list_free(filters);
	filters = NULL;
  c2_dynamic_module_signal_disconnect (module->name, C2_DYNAMIC_MODULE_MESSAGE_DOWNLOAD_POP);
}

/* go trough each of the filtering rules, and if it finds a match,
 * apply the actions for that rule, and stop searching through the rules. */
static void plugin_on_download_message(Message *message, gchar **mailbox)
{
	struct Filter *filter;
	int i;
	
	for(i=0; i < g_list_length(filters); i++) {
		filter = g_list_nth_data(filters, i);
		if(match_message(message, filter->match) == TRUE)
			act_upon_message(message, mailbox, filter->action);
	}
}

static gboolean match_message(Message *message, gchar *match) {
	gchar *header, *str, *mheader;
	gint i = 0;
	gboolean return_val = FALSE;
	
	for(i = 0; ;i += 3) 
	{
		header = filters_get_word(i+1, match);
		str = filters_get_word(i+2, match);
		message_get_message_header(message, NULL);
		mheader = message_get_header_field(message, NULL, header);		
		if(str && mheader)
			if(fnmatch(str, mheader, FNM_CASEFOLD) == 0)
				return_val = TRUE;
		c2_free(mheader);
		c2_free(header);
		c2_free(str);
    str = filters_get_word(i+3, match);
		if(!strneq(str, "and", 3) || return_val == FALSE) {
			c2_free(str);
			break;
		}
		else 
		{
			return_val = FALSE;			 
      c2_free(str);
		}
	}
	
	return return_val;
}

/* function below still needs some more actions */
static void act_upon_message(Message *message, gchar **mailbox, gchar *action) {
	gint i;
  gchar *act;
	
	for(i=1; ; i+=2) 
	{
		act =filters_get_word(i, action);
		if(strneq(act, "move", 4)) /* move the message */
		{
			gchar *to = filters_get_word(i+1, action);
			*mailbox = g_strdup(to);
			c2_free(to);
			i++;
		}
		else if(strneq(act, "delete", 6)) /* move message to garbage... */
			*mailbox = g_strdup("Garbage");
		else if(strneq(act, "beep", 4)) /* beep the message */
		{
			/* TODO: add sound functionality..? */
			printf("\a");
			fflush(NULL);
		}
		else if(strneq(act, "copy", 4)) /* copy message to another mailbox */
		{
			gchar *to = filters_get_word(i+1, action);
			gchar *buf;
			mid_t mid;
			FILE *file;
			Mailbox *mbox;
			
			i++;
			
			mbox = search_mailbox_name(config->mailbox_head, to);
			if(mbox)
		  {
				mid = c2_mailbox_get_next_mid(mbox);
				buf = c2_mailbox_mail_path(to, mid);
				if((file = fopen(buf, "w")) != NULL)
				{
					c2_free(buf);
					fprintf(file, "%s", message->message);
					fclose(file);
					buf = c2_mailbox_index_path(to);
					if((file = fopen(buf, "a")) != NULL) 
					{
						gchar *header[3];
						gchar *content_type;
						gboolean with_attachs = FALSE;

						header[0] = message_get_header_field(message, NULL, "\nSubject:");
						header[1] = message_get_header_field(message, NULL, "\nFrom:");
						header[2] = message_get_header_field(message, NULL, "\nDate:");
						content_type = message_get_header_field(message, NULL, "\nContent-Type:");
			 	    if(!header[0]) header[0] = "";
	 			    if(!header[1]) header[1] = "";
						if(!header[2]) header[2] = "";
						if(!content_type) content_type = "";
			      fprintf (file, "N\r\r%s\r%s\r%s\r%s\r%s\r%d\n",
										 with_attachs ? "1" : "", header[0], header[1], header[2],
										 "", mid);
						if(header[0] != "") c2_free(header[0]);
						if(header[1] != "") c2_free(header[1]);
						if(header[2] != "") c2_free(header[2]);
						if(content_type != "") c2_free(content_type);
						fclose(file);
					}
					else
						c2_free(buf);
				}
				else
					c2_free(buf);
			}
		}
		c2_free(act);
		act = filters_get_word(i+1, action);
		if(!strneq(act, "and", 3)) 
		{
			c2_free(act);
			break;
		}
		c2_free(act);
	}
}

/**
 * filters_get_word
 * @num: Position of the desired word.
 * @str: A pointer to a string containing the target.
 *
 * Finds the word in position @num. This function is
 * meant to evaluate filters descriptions, match, or action
 * strings. Fields are seperated by the character '~'
 * except when escaped with a '/'. '/' itself may be
 * escaped with an additional '/' placed directly 
 * before it.
 *
 * Return Value:
 * A freeable string containing the desired word or
 * NULL in case it doesn't exists.
 **/
gchar *filters_get_word(gint num, const gchar *str)
{
	guint i;
	GString *gstr = NULL;
	gchar *return_val;
	gboolean escape = FALSE;
	
	if(!str)
		return NULL;
	
	gstr = g_string_new(NULL);
	
	for(i = 0; i < strlen(str); i++)
	{
		if(str[i] == '/' && !escape) escape = TRUE;
		else if(str[i] == '/' && escape) {
			escape = FALSE;
			if(num == 0)
				g_string_append_c(gstr, str[i]);
		}
		else if(str[i] == '~' && !escape) num--;
		else if(str[i] == '~' && escape) {
			escape = FALSE;
			if(num == 0)
				g_string_append_c(gstr, str[i]);
		}
		else if(num == 0) gstr = g_string_append_c(gstr, str[i]);
		else if(num < 0) break;
	}
	
	return_val = gstr->str;
	g_string_free(gstr, FALSE);
	return return_val;
}

/* ------------- */
/* GUI Functions */
/* ------------- */
static GtkWidget *plugin_filters_configure(C2DynamicModule *module)
{
	GtkWidget *window;
  GtkWidget *dock1;
  GtkWidget *toolbar1;
  GtkWidget *tmp_toolbar_icon;
  GtkWidget *button1;
  GtkWidget *button2;
  GtkWidget *button3;
	GtkWidget *button4;
  GtkWidget *scrolledwindow1;
  GtkWidget *label1;
  GtkWidget *label2;
  GtkWidget *appbar1;

  window = gnome_app_new ("CronosII Message Filters", _("CronosII Message Filters"));
	gtk_signal_connect(GTK_OBJECT(window), "delete_event",
										 GTK_SIGNAL_FUNC(plugin_filters_on_configure_close), module);
	gtk_window_set_default_size(GTK_WINDOW(window), 400, 300);
	gtk_widget_show(window);
	
  dock1 = GNOME_APP (window)->dock;
  gtk_widget_ref (dock1);
  gtk_object_set_data_full (GTK_OBJECT (window), "dock1", dock1,
                            (GtkDestroyNotify) gtk_widget_unref);
  gtk_widget_show (dock1);

  toolbar1 = gtk_toolbar_new (GTK_ORIENTATION_HORIZONTAL, GTK_TOOLBAR_BOTH);
  gtk_widget_show (toolbar1);
  gnome_app_add_toolbar (GNOME_APP (window), GTK_TOOLBAR (toolbar1), "toolbar1",
                                GNOME_DOCK_ITEM_BEH_EXCLUSIVE,
                                GNOME_DOCK_TOP, 1, 0, 0);
  gtk_container_set_border_width (GTK_CONTAINER (toolbar1), 1);
  gtk_toolbar_set_space_size (GTK_TOOLBAR (toolbar1), 16);
  gtk_toolbar_set_space_style (GTK_TOOLBAR (toolbar1), GTK_TOOLBAR_SPACE_LINE);
  gtk_toolbar_set_button_relief (GTK_TOOLBAR (toolbar1), GTK_RELIEF_NONE);

  tmp_toolbar_icon = gnome_stock_pixmap_widget (window, GNOME_STOCK_PIXMAP_NEW);
  button1 = gtk_toolbar_append_element (GTK_TOOLBAR (toolbar1),
                                GTK_TOOLBAR_CHILD_BUTTON,
                                NULL,
                                _("New"),
                                _("New Filtering Rule"), NULL,
                                tmp_toolbar_icon, NULL, NULL);
	gtk_signal_connect(GTK_OBJECT(button1), "clicked",
										 GTK_SIGNAL_FUNC(plugin_filters_on_new_filter), window);
  gtk_widget_show(button1);

  tmp_toolbar_icon = gnome_stock_pixmap_widget (window, GNOME_STOCK_PIXMAP_PROPERTIES);
  button2 = gtk_toolbar_append_element (GTK_TOOLBAR (toolbar1),
                                GTK_TOOLBAR_CHILD_BUTTON,
                                NULL,
                                _("Edit"),
                                _("Edit Filtering Rule"), NULL,
                                tmp_toolbar_icon, NULL, NULL);
	gtk_signal_connect(GTK_OBJECT(button2), "clicked",
										 GTK_SIGNAL_FUNC(plugin_filters_on_edit_filter), window);
  gtk_widget_show(button2);

  tmp_toolbar_icon = gnome_stock_pixmap_widget (window, GNOME_STOCK_PIXMAP_CLOSE);
  button3 = gtk_toolbar_append_element (GTK_TOOLBAR (toolbar1),
                                GTK_TOOLBAR_CHILD_BUTTON,
                                NULL,
                                _("Delete"),
                                _("Delete Filtering Rule"), NULL,
                                tmp_toolbar_icon, NULL, NULL);
  gtk_widget_show(button3);
	
	tmp_toolbar_icon = gnome_stock_pixmap_widget(window, GNOME_STOCK_PIXMAP_EXIT);
	button4 = gtk_toolbar_append_element(GTK_TOOLBAR(toolbar1),
																			 GTK_TOOLBAR_CHILD_BUTTON,
																			 NULL,
																			 _("Exit"),
																			 _("Exit Filters Configuration"), NULL,
																			 tmp_toolbar_icon, NULL, NULL);
	gtk_signal_connect(GTK_OBJECT(button4), "clicked",
										 GTK_SIGNAL_FUNC(plugin_filters_on_configure_exit), module);
	gtk_widget_show(button4);

  scrolledwindow1 = gtk_scrolled_window_new (NULL, NULL);
  gtk_widget_show (scrolledwindow1);
  gnome_app_set_contents (GNOME_APP (window), scrolledwindow1);

  filters_clist = gtk_clist_new(2);
  gtk_widget_show (filters_clist);
  gtk_container_add (GTK_CONTAINER (scrolledwindow1), filters_clist);
  gtk_clist_set_column_width (GTK_CLIST (filters_clist), 0, 110);
  gtk_clist_set_column_width (GTK_CLIST (filters_clist), 1, 450);
  gtk_clist_column_titles_show (GTK_CLIST (filters_clist));
	plugin_filters_fill_clist();
	gtk_signal_connect(GTK_OBJECT(button3), "clicked",
										 GTK_SIGNAL_FUNC(plugin_filters_on_delete_filter), NULL);
	
  label1 = gtk_label_new (_("Name"));
  gtk_widget_show (label1);
  gtk_clist_set_column_widget (GTK_CLIST (filters_clist), 0, label1);

  label2 = gtk_label_new (_("Description"));
  gtk_widget_show (label2);
  gtk_clist_set_column_widget (GTK_CLIST (filters_clist), 1, label2);

  appbar1 = gnome_appbar_new (TRUE, TRUE, GNOME_PREFERENCES_NEVER);
  gtk_widget_show (appbar1);
  gnome_app_set_statusbar (GNOME_APP (window), appbar1);

	main_window = window;
  return window;
}

static gboolean plugin_filters_on_configure_close(GtkWidget *widget, GdkEvent *event,
																							C2DynamicModule *module)
{
	plugin_filters_save_config(module->configfile);
	gtk_widget_destroy(widget);
	return TRUE;
}

static void plugin_filters_on_configure_exit(GtkButton *widget, C2DynamicModule *module)
{
	plugin_filters_save_config(module->configfile);
	gtk_widget_destroy(main_window);
}

static void plugin_filters_fill_clist(void)
{
	gint i;
	struct Filter *filter;
	gchar *notes[2];
	
	gtk_clist_freeze(GTK_CLIST(filters_clist));
	gtk_clist_clear(GTK_CLIST(filters_clist));
	
	for(i=0; i < g_list_length(filters); i++) 
	{
		filter = g_list_nth_data(filters, i);
		notes[0] = filters_get_word(0, filter->notes);
		notes[1] = filters_get_word(1, filter->notes);
		gtk_clist_append(GTK_CLIST(filters_clist), notes);
		c2_free(notes[0]);
		c2_free(notes[1]);
	}
	
	gtk_clist_thaw(GTK_CLIST(filters_clist));
}

static void plugin_filters_on_new_filter(GtkButton *button, GtkWidget *widget)
{
	plugin_filters_draw_edit_filter_window(button, widget, -1);
}

static void plugin_filters_on_edit_filter(GtkButton *button, GtkWidget *widget)
{
	if(!(GTK_CLIST(filters_clist)->selection) || 
		 g_list_length(GTK_CLIST(filters_clist)->selection) != 1)  
		return;
	else
	{
		gint i;
		i = GPOINTER_TO_INT(g_list_nth_data(GTK_CLIST(filters_clist)->selection, 0));
	  plugin_filters_draw_edit_filter_window(button, widget, i);
	}
}

static void plugin_filters_draw_edit_filter_window(GtkButton *button, GtkWidget *widget, gint edit)
{
	GtkWidget *vbox1;
	GtkWidget *hbox1;
	GtkWidget *label3;
	GtkWidget *hbox2;
	GtkWidget *label4;
	GtkWidget *hbox3;
  GtkWidget *label5;
  GtkWidget *label6;
  GtkWidget *combo1;
  GtkWidget *AddButton;
  GtkWidget *hbox4;
  GtkWidget *RemoveButton;
  GtkWidget *frame1;
	GtkWidget *framevbox;
	GtkWidget *framehbox1;
	GtkWidget *framehbox2;
	GtkWidget *OkButton;
	
	struct new_filter_fields *filter_fields;
	filter_fields = g_new0(struct new_filter_fields, 1);
	filter_fields->edit = edit;

  filter_fields->window = gtk_window_new (GTK_WINDOW_TOPLEVEL);
  gtk_container_set_border_width (GTK_CONTAINER (filter_fields->window), 5);
  gtk_window_set_title (GTK_WINDOW (filter_fields->window), _("New Filter"));

  vbox1 = gtk_vbox_new (FALSE, 0);
  gtk_widget_show (vbox1);
  gtk_container_add (GTK_CONTAINER (filter_fields->window), vbox1);

  hbox1 = gtk_hbox_new (FALSE, 0);
  gtk_widget_show (hbox1);
  gtk_box_pack_start (GTK_BOX (vbox1), hbox1, TRUE, TRUE, 0);

  label3 = gtk_label_new (_("Filter Name"));
  gtk_widget_show (label3);
  gtk_box_pack_start (GTK_BOX (hbox1), label3, FALSE, FALSE, 3);

  filter_fields->NameEntry = gtk_entry_new_with_max_length (256);
  gtk_widget_show (filter_fields->NameEntry);
  gtk_box_pack_start (GTK_BOX (hbox1), filter_fields->NameEntry, TRUE, TRUE, 0);

  hbox2 = gtk_hbox_new (FALSE, 0);
  gtk_widget_show (hbox2);
  gtk_box_pack_start (GTK_BOX (vbox1), hbox2, TRUE, TRUE, 0);

  label4 = gtk_label_new (_("Description"));
  gtk_widget_show (label4);
  gtk_box_pack_start (GTK_BOX (hbox2), label4, FALSE, FALSE, 3);

  filter_fields->DescriptionEntry = gtk_entry_new ();
  gtk_widget_show (filter_fields->DescriptionEntry);
  gtk_box_pack_start (GTK_BOX (hbox2), filter_fields->DescriptionEntry, TRUE, TRUE, 0);

  hbox3 = gtk_hbox_new (FALSE, 0);
  gtk_widget_show (hbox3);
  gtk_box_pack_start (GTK_BOX (vbox1), hbox3, TRUE, TRUE, 0);

  label5 = gtk_label_new (_("Match Text:"));
  gtk_widget_show (label5);
  gtk_box_pack_start (GTK_BOX (hbox3), label5, FALSE, FALSE, 0);
  gtk_misc_set_padding (GTK_MISC (label5), 5, 0);

  filter_fields->MatchTextEntry = gtk_entry_new_with_max_length (256);
  gtk_widget_show (filter_fields->MatchTextEntry);
  gtk_box_pack_start (GTK_BOX (hbox3), filter_fields->MatchTextEntry, TRUE, TRUE, 0);

  label6 = gtk_label_new (_("in"));
  gtk_widget_show (label6);
  gtk_box_pack_start (GTK_BOX (hbox3), label6, FALSE, FALSE, 0);
  gtk_misc_set_padding (GTK_MISC (label6), 5, 0);

	{	
		GList *headers = NULL;
		headers = g_list_append(headers, "To:");
		headers = g_list_append(headers, "CC:");
		headers = g_list_append(headers, "From:");
		headers = g_list_append(headers, "Date:");
		headers = g_list_append(headers, "Subject:");
		/*(TODO) headers = g_list_append(headers, "Message Body");*/
		/*(TODO) headers = g_list_append(headers, "Entire Message");*/

		combo1 = gtk_combo_new ();
		gtk_combo_set_popdown_strings(GTK_COMBO(combo1), headers);
    gtk_combo_set_value_in_list(GTK_COMBO(combo1), TRUE, FALSE);		
		gtk_widget_show (combo1);
		gtk_box_pack_start (GTK_BOX (hbox3), combo1, TRUE, TRUE, 0);
		
		g_list_free(headers);
	}
		
  filter_fields->MatchWhereCombo = GTK_COMBO (combo1)->entry;
  gtk_widget_show (filter_fields->MatchWhereCombo);

  AddButton = gtk_button_new_with_label (_("Add"));
	gtk_container_set_border_width(GTK_CONTAINER(AddButton), 10);
	gtk_signal_connect(GTK_OBJECT(AddButton), "clicked",
										 GTK_SIGNAL_FUNC(plugin_filters_new_on_add_match_rule), filter_fields);
  gtk_widget_show (AddButton);
  gtk_box_pack_start (GTK_BOX (hbox3), AddButton, FALSE, FALSE, 0);

  hbox4 = gtk_hbox_new (FALSE, 0);
  gtk_widget_show (hbox4);
  gtk_box_pack_start (GTK_BOX (vbox1), hbox4, TRUE, TRUE, 0);

  filter_fields->MatchList = gtk_clist_new(2);
	gtk_clist_set_column_width(GTK_CLIST(filter_fields->MatchList), 0, 100);
	gtk_clist_set_column_width(GTK_CLIST(filter_fields->MatchList), 1, 50);
  gtk_widget_show (filter_fields->MatchList);
  gtk_box_pack_start (GTK_BOX (hbox4), filter_fields->MatchList, TRUE, TRUE, 0);

  RemoveButton = gtk_button_new_with_label (_("Remove Match"));
  gtk_box_pack_start (GTK_BOX (hbox4), RemoveButton, TRUE, FALSE, 0);
	gtk_signal_connect(GTK_OBJECT(RemoveButton), "clicked",
										 GTK_SIGNAL_FUNC(plugin_filters_new_on_remove_match_rule), filter_fields);
	gtk_widget_show (RemoveButton);
	
  frame1 = gtk_frame_new (_("Actions"));
  gtk_widget_show (frame1);
  gtk_box_pack_start (GTK_BOX (vbox1), frame1, TRUE, TRUE, 0);
  gtk_container_set_border_width (GTK_CONTAINER (frame1), 2);

	framevbox = gtk_vbox_new(FALSE, 2);
	gtk_container_add(GTK_CONTAINER(frame1), framevbox);
	gtk_widget_show(framevbox);
	
	framehbox1 = gtk_hbox_new(FALSE, 0);
	gtk_box_pack_start(GTK_BOX(framevbox), framehbox1,
										 FALSE, FALSE, 0);
	gtk_widget_show(framehbox1);
	
	filter_fields->CopyButton = gtk_check_button_new_with_label(_("Copy message to: "));
	gtk_box_pack_start(GTK_BOX(framehbox1), filter_fields->CopyButton,
										 FALSE, FALSE, 0);
	gtk_widget_show(filter_fields->CopyButton);
	
	filter_fields->CopyMailboxCombo = plugin_filters_gui_build_mailbox_combo();
	gtk_box_pack_start(GTK_BOX(framehbox1), filter_fields->CopyMailboxCombo,
										 TRUE, TRUE, 5);
	gtk_widget_show(filter_fields->CopyMailboxCombo);

	framehbox2 = gtk_hbox_new(FALSE, 0);
	gtk_box_pack_start(GTK_BOX(framevbox), framehbox2,
										 FALSE, FALSE, 0);
	gtk_widget_show(framehbox2);
	
	filter_fields->MoveButton = gtk_check_button_new_with_label(_("Move message to: "));
	gtk_signal_connect(GTK_OBJECT(filter_fields->MoveButton), "clicked",
										 GTK_SIGNAL_FUNC(plugin_filters_new_on_move_button), filter_fields);
	gtk_box_pack_start(GTK_BOX(framehbox2), filter_fields->MoveButton,
										 FALSE, FALSE, 0);
	gtk_widget_show(filter_fields->MoveButton);

	filter_fields->MoveMailboxCombo = plugin_filters_gui_build_mailbox_combo();
	gtk_box_pack_start(GTK_BOX(framehbox2), filter_fields->MoveMailboxCombo,
										 TRUE, TRUE, 5);
	gtk_widget_show(filter_fields->MoveMailboxCombo);
	
	filter_fields->DeleteButton = gtk_check_button_new_with_label(_("Delete Message"));
	gtk_signal_connect(GTK_OBJECT(filter_fields->DeleteButton), "clicked",
										 GTK_SIGNAL_FUNC(plugin_filters_new_on_delete_button), filter_fields);
	gtk_box_pack_start(GTK_BOX(framevbox), filter_fields->DeleteButton,
										 FALSE, FALSE, 0);
	gtk_widget_show(filter_fields->DeleteButton);
	
	filter_fields->BeepButton = gtk_check_button_new_with_label(_("Produce a System Beep"));
	gtk_box_pack_start(GTK_BOX(framevbox), filter_fields->BeepButton,
										 FALSE, FALSE, 0);
	gtk_widget_show(filter_fields->BeepButton);
	
	OkButton = gnome_stock_button(GNOME_STOCK_BUTTON_OK);
	gtk_box_pack_start(GTK_BOX(vbox1), OkButton,
										 TRUE, TRUE, 3);
	gtk_signal_connect(GTK_OBJECT(OkButton), "clicked",
										 GTK_SIGNAL_FUNC(plugin_filters_edit_filter), filter_fields);
	gtk_widget_show(OkButton);
	
	gtk_window_set_transient_for (GTK_WINDOW (widget), GTK_WINDOW (filter_fields->window));
	gtk_window_set_modal (GTK_WINDOW (widget), FALSE);
	gtk_window_set_modal (GTK_WINDOW (filter_fields->window), TRUE);
	
	/* if this is a new filter... we're done */
	if(edit < 0) 
  {
		gtk_widget_show(filter_fields->window);
		return;
	}
  
	/* otherwise keep going to fill in the fields */
  else
  {
		struct Filter *filter;
		gchar *temp;
		gchar *list[2] = { NULL, NULL };
		gint i;
		
		filter = g_list_nth_data(filters, edit);
		temp = filters_get_word(0, filter->notes);
		gtk_entry_set_text(GTK_ENTRY(filter_fields->NameEntry), temp);
		c2_free(temp);
		temp = filters_get_word(1, filter->notes);
		gtk_entry_set_text(GTK_ENTRY(filter_fields->DescriptionEntry), temp);
		c2_free(temp);
		
		/* fill in the match list */
		for(i=0; ;i+=3)
		{
			temp = filters_get_word(i+1, filter->match);
			if(strlen(temp) > 0)
				list[0] = temp;
			temp = filters_get_word(i+2, filter->match);
			if(strlen(temp) > 0)
				list[1] = temp;
			if(list[0] && list[1])
				gtk_clist_append(GTK_CLIST(filter_fields->MatchList), list);
			c2_free(list[0]);
			c2_free(list[1]);
			temp = filters_get_word(i+3, filter->match);
			if(temp != NULL && streq(temp, "and")) {
				c2_free(temp); /* carry on.. */
			}
			else
			{
				c2_free(temp); /* bust out... */
				break;
			}
		}
		
		/* check off the right action buttons */
	  for(i=1; ; i+=2)
		{
			temp =filters_get_word(i, filter->action);
      if(strneq(temp, "copy", 4))
			{
				gchar *to = filters_get_word(i+1, filter->action);
				gtk_toggle_button_set_active(GTK_TOGGLE_BUTTON(filter_fields->CopyButton), TRUE);
 				gtk_entry_set_text(GTK_ENTRY(GTK_COMBO(filter_fields->CopyMailboxCombo)->entry), to);
				c2_free(to);
				i++;
			}
			else if(strneq(temp, "move", 4)) 
			{
				gchar *to = filters_get_word(i+1, filter->action);
				gtk_toggle_button_set_active(GTK_TOGGLE_BUTTON(filter_fields->MoveButton), TRUE);
        gtk_toggle_button_set_active(GTK_TOGGLE_BUTTON(filter_fields->DeleteButton), FALSE);
        gtk_widget_set_sensitive(filter_fields->DeleteButton, FALSE);
				gtk_entry_set_text(GTK_ENTRY(GTK_COMBO(filter_fields->MoveMailboxCombo)->entry), to);
				c2_free(to);
				i++;
			}
      else if(strneq(temp, "delete", 6))
			{
				gtk_toggle_button_set_active(GTK_TOGGLE_BUTTON(filter_fields->DeleteButton), TRUE);
        gtk_toggle_button_set_active(GTK_TOGGLE_BUTTON(filter_fields->MoveButton), FALSE);
				gtk_widget_set_sensitive(filter_fields->MoveButton, FALSE);
				gtk_widget_set_sensitive(filter_fields->MoveMailboxCombo, FALSE);
			}
      else if(strneq(temp, "beep", 4))
			{
				gtk_toggle_button_set_active(GTK_TOGGLE_BUTTON(filter_fields->BeepButton), TRUE);
			} 
			c2_free(temp);
      temp = filters_get_word(i+1, filter->action);
			if(!strneq(temp, "and", 3))
			{
				c2_free(temp);
 	      break;
			}
			c2_free(temp);
		}
		
		gtk_widget_show(filter_fields->window);
	}
}

static GtkWidget *plugin_filters_gui_build_mailbox_combo(void)
{
	GtkWidget *combo;
	GList *mailbox_list = NULL;
	Mailbox *box = config->mailbox_head;
	
	do
	{
		mailbox_list = g_list_append(mailbox_list, box->name);
		box = box->next;
	}
	while(box);
		 
	combo = gtk_combo_new();
	gtk_combo_set_popdown_strings(GTK_COMBO(combo), mailbox_list);
	gtk_combo_set_value_in_list(GTK_COMBO(combo), TRUE, FALSE);
	g_list_free(mailbox_list);
	
	return combo;
}

static void plugin_filters_new_on_add_match_rule(GtkButton *button, 
																								 struct new_filter_fields *fields)
{
	gchar *temp[2];
	temp[0] = gtk_editable_get_chars(GTK_EDITABLE(fields->MatchTextEntry), 0, -1);
	temp[1] = gtk_editable_get_chars(GTK_EDITABLE(fields->MatchWhereCombo), 0, -1);
	
	gtk_clist_append(GTK_CLIST(fields->MatchList), temp);
	c2_free(temp[0]);
	c2_free(temp[1]);
}

static void plugin_filters_new_on_remove_match_rule(GtkButton *button, 
																										struct new_filter_fields *fields)
{
	gint i;
	i = GPOINTER_TO_INT(g_list_nth_data(GTK_CLIST(fields->MatchList)->selection, 0));
	if(GTK_CLIST(fields->MatchList)->selection)
		gtk_clist_remove(GTK_CLIST(fields->MatchList), i);
}

static void plugin_filters_new_on_delete_button(GtkButton *button,
																								struct new_filter_fields *fields)
{
	if(GTK_TOGGLE_BUTTON(fields->DeleteButton)->active == TRUE)
	{
		gtk_toggle_button_set_active(GTK_TOGGLE_BUTTON(fields->MoveButton), FALSE);
		gtk_widget_set_sensitive(fields->MoveButton, FALSE);
		gtk_widget_set_sensitive(fields->MoveMailboxCombo, FALSE);
	}
	else
  {
		gtk_widget_set_sensitive(fields->MoveButton, TRUE);
		gtk_widget_set_sensitive(fields->MoveMailboxCombo, TRUE);
	}
}

static void plugin_filters_new_on_move_button(GtkButton *button,
																							struct new_filter_fields *fields)
{
	if(GTK_TOGGLE_BUTTON(fields->MoveButton)->active == TRUE)
	{
		gtk_toggle_button_set_active(GTK_TOGGLE_BUTTON(fields->DeleteButton), FALSE);
		gtk_widget_set_sensitive(fields->DeleteButton, FALSE);
	}
	else
		gtk_widget_set_sensitive(fields->DeleteButton, TRUE);
}

static void plugin_filters_edit_filter(GtkButton *button, struct new_filter_fields *fields)
{
  gchar *str1, *str2, *tempstr;
	gint i;
	struct Filter *filter;
	GString *gstr;
	
	filter = g_new0(struct Filter, 1);
	
	/* the name + description */
	str1 = gtk_editable_get_chars(GTK_EDITABLE(fields->NameEntry), 0, -1);
	str2 = gtk_editable_get_chars(GTK_EDITABLE(fields->DescriptionEntry), 0, -1);
	str1 = str_replace_all(str1, "/", "//");
	tempstr = str1;
	str1 = str_replace_all(str1, "~", "/~");
	c2_free(tempstr);
	str2 = str_replace_all(str2, "/", "//");
	tempstr = str2;
	str2 = str_replace_all(str2, "~", "/~");
	c2_free(tempstr);
	filter->notes = g_strconcat(str1, "~", str2, NULL);
	c2_free(str1);
	c2_free(str2);
	
	/* the matching rules */
		
	gstr = g_string_new("match~");

 	for(i=0; i < GTK_CLIST(fields->MatchList)->rows; i++)
	{
	  gtk_clist_get_text(GTK_CLIST(fields->MatchList), i, 0, &str2);
		gtk_clist_get_text(GTK_CLIST(fields->MatchList), i, 1, &str1);
		str2 = str_replace_all(str2, "/", "//");
		tempstr = str2;
		str2 = str_replace_all(str2, "~", "/~");
		c2_free(tempstr);
		str1 = str_replace_all(str1, "/", "//");
		tempstr = str1;
		str1 = str_replace_all(str1, "~", "/~");
		c2_free(tempstr);
 	  gstr = g_string_append(gstr, str1);
		gstr = g_string_append(gstr, "~");
		gstr = g_string_append(gstr, str2);
		c2_free(str1);
		c2_free(str2);
		if(i+1 < GTK_CLIST(fields->MatchList)->rows)
			gstr = g_string_append(gstr, "~AND~");
	}
		
	filter->match = gstr->str;
	g_string_free(gstr, FALSE);
	
	gstr = g_string_new("action~");
	
	/* the actions to take on messages */
	if(GTK_TOGGLE_BUTTON(fields->CopyButton)->active == TRUE)
	{
		gchar *mbox = gtk_editable_get_chars(GTK_EDITABLE(GTK_COMBO(fields->CopyMailboxCombo)->entry), 0, -1);
		gstr = g_string_append(gstr, "copy~");
		gstr = g_string_append(gstr, mbox);
	}
	if(GTK_TOGGLE_BUTTON(fields->MoveButton)->active == TRUE)
	{
		gchar *mbox = gtk_editable_get_chars(GTK_EDITABLE(GTK_COMBO(fields->MoveMailboxCombo)->entry), 0, -1);
	  if(gstr->len > 7)
			gstr = g_string_append(gstr, "~AND~");
		gstr = g_string_append(gstr, "move~");
		gstr = g_string_append(gstr, mbox);
	}
	if(GTK_TOGGLE_BUTTON(fields->DeleteButton)->active == TRUE)
	{
		if(gstr->len > 7)
			gstr = g_string_append(gstr, "~AND~");
		gstr = g_string_append(gstr, "delete");
	}
	if(GTK_TOGGLE_BUTTON(fields->BeepButton)->active == TRUE)
	{
		if(gstr->len > 7) 
			gstr = g_string_append(gstr, "~AND~");
		gstr = g_string_append(gstr, "beep");
	}
  
	filter->action = gstr->str;
	g_string_free(gstr, FALSE);

	gtk_widget_destroy(fields->window);
	
	if(fields->edit < 0)
		filters = g_list_append(filters, filter);
	else
	{
		GList *link;
		struct Filter *old_filter;
		
		link = g_list_nth(filters, fields->edit);
		filters = g_list_remove_link(filters, link);
		
		old_filter = link->data;
		c2_free(old_filter->notes);
		c2_free(old_filter->match);
		c2_free(old_filter->action);
		g_list_free_1(link);
		
		filters = g_list_insert(filters, filter, fields->edit);
	}
	
	gtk_widget_destroy(fields->window);
	plugin_filters_fill_clist();
}

static void plugin_filters_on_delete_filter(void)
{
	GList *temp;
  gint i;
	
	if(!(GTK_CLIST(filters_clist)->selection) || g_list_length(GTK_CLIST(filters_clist)->selection) != 1)
		return;
	else
	{
		i = GPOINTER_TO_INT(g_list_nth_data(GTK_CLIST(filters_clist)->selection, 0));
		temp = g_list_nth(filters, i);
		filters = g_list_remove_link(filters, temp);
		c2_free(temp->data);
		g_list_free(temp);
		gtk_clist_remove(GTK_CLIST(filters_clist), i);
	}
}
